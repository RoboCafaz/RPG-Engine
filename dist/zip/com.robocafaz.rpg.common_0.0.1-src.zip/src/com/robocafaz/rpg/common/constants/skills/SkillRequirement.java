package com.robocafaz.rpg.common.constants.skills;

public class SkillRequirement {

}
