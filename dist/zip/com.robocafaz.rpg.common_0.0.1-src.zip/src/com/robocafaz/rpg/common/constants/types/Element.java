package com.robocafaz.rpg.common.constants.types;

import com.robocafaz.rpg.common.constants.UserFacingConstant;

public class Element extends UserFacingConstant implements Expertise {
  public Element(String id, String name, String description) {
    super(id, name, description);
  }
}
