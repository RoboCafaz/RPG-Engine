package com.robocafaz.rpg.common.constants.types;

public interface Expertise {

}
