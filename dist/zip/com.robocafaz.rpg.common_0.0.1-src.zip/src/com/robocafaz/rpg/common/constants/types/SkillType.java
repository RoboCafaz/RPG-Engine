package com.robocafaz.rpg.common.constants.types;

import com.robocafaz.rpg.common.constants.UserFacingConstant;

public class SkillType extends UserFacingConstant {
  public SkillType(String id, String name, String description) {
    super(id, name, description);
  }
}