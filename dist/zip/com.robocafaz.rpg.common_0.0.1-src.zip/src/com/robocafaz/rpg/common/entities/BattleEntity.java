package com.robocafaz.rpg.common.entities;

public abstract class BattleEntity extends Entity {

  public BattleEntity(String name) {
    super(name);

  }

}
